<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use App\Models\Area;
use App\Models\Apartment;
use App\Models\Customer;
use Illuminate\Support\Facades\Hash;

class ProductsController extends Controller
{
    //
}
