<p>Your OTP code is: <strong><?php echo e($otpCode); ?></strong></p>
<p>This code will expire in 10 minutes.</p>
<p>Thank you for using our application!</p>
<?php /**PATH C:\xampp\htdocs\waterapp\resources\views/emails/otp.blade.php ENDPATH**/ ?>