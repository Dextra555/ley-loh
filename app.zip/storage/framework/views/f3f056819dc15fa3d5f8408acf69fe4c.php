<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('paper')); ?>/img/apple-icon.png">
    <link rel="icon" type="image/png" href="<?php echo e(asset('paper')); ?>/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        <?php echo e(__('Ley Loh')); ?>

    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('paper')); ?>/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('paper')); ?>/css/paper-dashboard.css?v=2.0.0" rel="stylesheet" />
    <link href="<?php echo e(asset('paper')); ?>/demo/demo.css" rel="stylesheet" />

</head>

<body class="<?php echo e($class); ?>">
    
    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('layouts.page_templates.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->make('layouts.page_templates.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <script src="<?php echo e(asset('paper')); ?>/js/core/jquery.min.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/core/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/plugins/chartjs.min.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/plugins/bootstrap-notify.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/js/paper-dashboard.min.js?v=2.0.0" type="text/javascript"></script>
    <script src="<?php echo e(asset('paper')); ?>/demo/demo.js"></script>
    <script src="<?php echo e(asset('paper')); ?>/demo/jquery.sharrre.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php echo $__env->make('layouts.navbars.fixed-plugin-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /home/bookyou2/public_html/leyloh/resources/views/layouts/app.blade.php ENDPATH**/ ?>