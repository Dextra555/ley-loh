<div class="sidebar" data-color="black" data-active-color="danger">
    <div class="logo">
        <a href="" class="simple-text logo-mini">
            <div class="logo-image-small">
                <img src="<?php echo e(asset('paper')); ?>/img/logo.png">
            </div>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php echo e($elementActive == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'dashboard')); ?>">
                    <i class="nc-icon nc-bank"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            

            <li class="<?php echo e($elementActive == 'orders' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('location')); ?>">
                <i class="nc-icon nc-app"></i>
                    <p><?php echo e(__('Orders')); ?></p>
                </a>
            </li>

            <li class="<?php echo e($elementActive == 'locations' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('location')); ?>">
                <i class="nc-icon nc-pin-3"></i>
                    <p><?php echo e(__('Location')); ?></p>
                </a>
            </li>

            <li class="<?php echo e($elementActive == 'apartment' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('apartment')); ?>">
                <i class="nc-icon nc-tile-56"></i>
                    <p><?php echo e(__('Appartments')); ?></p>
                </a>
            </li>

            <li class="<?php echo e($elementActive == 'vendors-manage' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="false" href="#vendorsMenu">
                <i class="nc-icon nc-badge"></i>
                    <p>
                            <?php echo e(__('Vendors')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="vendorsMenu">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'vendors-add' ? 'active' : ''); ?>">
                            <a href="">
                                <span class="sidebar-mini-icon"><?php echo e(__('AV')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('Add Vendor')); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e($elementActive == 'vendors-list' ? 'active' : ''); ?>">
                            <a href="">
                                <span class="sidebar-mini-icon"><?php echo e(__('LV')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('List Vendors')); ?></span>
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </li>
            <li class="<?php echo e($elementActive == 'cus-manage' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="false" href="#cusMenu">
                <i class="nc-icon nc-single-02"></i>
                    <p>
                            <?php echo e(__('Customers')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse" id="cusMenu">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'cus-add' ? 'active' : ''); ?>">
                            <a href="">
                                <span class="sidebar-mini-icon"><?php echo e(__('AC')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('Add Customer')); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e($elementActive == 'cus-list' ? 'active' : ''); ?>">
                            <a href="">
                                <span class="sidebar-mini-icon"><?php echo e(__('LC')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__('List Customers')); ?></span>
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </li>
            <li class="<?php echo e($elementActive == 'icons' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'icons')); ?>">
                    <i class="nc-icon nc-diamond"></i>
                    <p><?php echo e(__('Icons')); ?></p>
                </a>
            </li>
             <li class="<?php echo e($elementActive == 'user' || $elementActive == 'profile' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="true" href="#laravelExamples">
                    <i class="nc-icon"><img src="<?php echo e(asset('paper/img/laravel.svg')); ?>"></i>
                    <p>
                            <?php echo e(__('Laravel examples')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExamples">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'profile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('UP')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' User Profile ')); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e($elementActive == 'user' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'user')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('U')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' User Management ')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            
            <li class="<?php echo e($elementActive == 'notifications' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'notifications')); ?>">
                    <i class="nc-icon nc-bell-55"></i>
                    <p><?php echo e(__('Notifications')); ?></p>
                </a>
            </li>
            
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\waterapp\resources\views/layouts/navbars/auth.blade.php ENDPATH**/ ?>